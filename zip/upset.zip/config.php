<?php
$controller_name = 'upset';
$model_name = 'upset_model';
$table_name = 'up_set';
?>