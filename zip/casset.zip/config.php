<?php
$controller_name = 'cas_set';
$model_name = 'cas_set_model';
$table_name = 'cas_set';
?>