<?php
$controller_name = 'lab_set';
$model_name = 'lab_set_model';
$table_name = 'lab_set';
?>