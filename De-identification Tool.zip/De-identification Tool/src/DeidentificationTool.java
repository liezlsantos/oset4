import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

@SuppressWarnings("serial")
public class DeidentificationTool extends JFrame implements ActionListener{

	private Deidentifier deidentifier;
	private JFileChooser fileChooser = new JFileChooser();
	private JMenu fileMenu = new JMenu("File"), helpMenu = new JMenu("Help");
	private JMenuBar menuBar = new JMenuBar();
	private JMenuItem openFile = new JMenuItem("Open File"),
					  instruction = new JMenuItem("Instructions"), 
					  exit = new JMenuItem("Exit");
	private JPanel mainPanel = new JPanel();
	private JLabel info = new JLabel(), 
				   csvFileLabel = new JLabel("Input File:"), 
				   methodsLabel = new JLabel();
	private JTextField inputFile = new JTextField(), 
					   noOfRecordsField = new JTextField(),
					   randomReplaceField = new JTextField(),
					   swapField = new JTextField(),
					   pseudonymField = new JTextField();
	private JButton	deidentifyButton = new JButton("De-identify");
	private String instructionMessage = "<html>" +
										"<br> <ol><li> Open the CSV file containing all the records to be de-identified. <br> " +
										"<br> <li> Enter the number of records to be disclosed. It must not exceed the total" +
										"<br> number of records. <br> " +
										"<br> <li> Type the field numbers (separated by comma e.g. 1,2,3) in the text field " +
										"<br> of each de-identification method. There should only be one method to be" +
										"<br> used per field (i.e. a field number appears at most one on the three text " +
										"<br> fields). <br> " +
										"<br> <li> Click the 'De-identify' button. <br> "+
										"<br> <li> Enter the filename of the csv file that will contain the de-identified data set and click save. <br> "+ 
										"</ol></html>";
	
	private static final Font PLAIN_FONT = new Font("Arial", Font.PLAIN, 13);	
		
	public DeidentificationTool()
	{
		super("De-identification Tool");
		setSize(630, 600);
		setResizable(false);
	
		fileMenu.setFont(PLAIN_FONT);
			openFile.addActionListener(this);
			openFile.setFont(PLAIN_FONT);
			fileMenu.add(openFile);
		menuBar.add(fileMenu);	
		
		helpMenu.setFont(PLAIN_FONT);
			instruction.addActionListener(this);
			instruction.setFont(PLAIN_FONT);
			helpMenu.add(instruction);
			exit.addActionListener(this);
			exit.setFont(PLAIN_FONT);
			helpMenu.add(exit);
		menuBar.add(helpMenu);	
		this.setJMenuBar(menuBar);
		
		mainPanel = new JPanel();
		mainPanel.setLayout(null);
		
			info.setFont(PLAIN_FONT);
			info.setText("Open a CSV file to start.");
			info.setBounds(10, 15, 700, 15);
			mainPanel.add(info);
			
		add(mainPanel);
		
		setLocationRelativeTo(null);
		setIconImage(new ImageIcon(this.getClass().getResource("icon.png")).getImage());
		
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	private void loadCSV(String inputFilename)
	{
		mainPanel.removeAll();
		
			info.setFont(PLAIN_FONT);
			info.setText("Choose the de-identification methods to be used");
			info.setBounds(10, 15, 700, 15);
			mainPanel.add(info);
						
			
			csvFileLabel.setFont(PLAIN_FONT);
			csvFileLabel.setBounds(10, 50, 80, 22);	
			mainPanel.add(csvFileLabel);
			inputFile.setFont(PLAIN_FONT);
			inputFile.setBounds(90, 50, 500, 22);
			inputFile.setText(inputFilename);
			inputFile.setEditable(false);
			inputFile.setBackground(Color.white);
			mainPanel.add(inputFile);	
			
			methodsLabel.setText("<html><b>SUBSAMPLING</b> <br><br> Enter the number of records to be disclosed (1-"+ deidentifier.getNoOfRecords() +"): <br><br><br><br>  " +
								 "<b>RANDOM REPLACEMENT</b> <br><br> Field numbers separated by comma (1-"+ deidentifier.getNoOfFields() +"): <br><br><br><br>" +
								 "<b>SWAPPING</b> <br><br> Field numbers separated by comma (1-"+ deidentifier.getNoOfFields() +"): <br><br><br><br>" +
								 "<b>PSEUDONYMIZATION</b> <br><br> Field numbers separated by comma (1-"+ deidentifier.getNoOfFields() +"): </html>");
			methodsLabel.setBounds(10, 70, 500, 400);
			methodsLabel.setFont(PLAIN_FONT);
			mainPanel.add(methodsLabel);
			
			noOfRecordsField.setBounds(340, 140, 100, 22);
			noOfRecordsField.setFont(PLAIN_FONT);
			mainPanel.add(noOfRecordsField);
			
			randomReplaceField.setBounds(270, 230, 150, 22);
			randomReplaceField.setFont(PLAIN_FONT);
			mainPanel.add(randomReplaceField);
			
			swapField.setBounds(270, 320, 150, 22);
			swapField.setFont(PLAIN_FONT);
			mainPanel.add(swapField);
			
			pseudonymField.setBounds(270, 410, 150, 22);
			pseudonymField.setFont(PLAIN_FONT);
			mainPanel.add(pseudonymField);
			
			deidentifyButton.setBounds(500, 490, 100, 25);
			deidentifyButton.addActionListener(this);
			mainPanel.add(deidentifyButton);
		
		mainPanel.revalidate();
		mainPanel.repaint();
	}
	
	public void actionPerformed(ActionEvent e) 
	{	
		if(e.getSource().equals(openFile))
		{
			int rVal = fileChooser.showOpenDialog(this);
	    	if (rVal == JFileChooser.APPROVE_OPTION) 
	    	{
	    		deidentifier = new Deidentifier(fileChooser.getCurrentDirectory().toString()+ "\\" + fileChooser.getSelectedFile().getName());
				loadCSV(fileChooser.getCurrentDirectory().toString()+ "\\" + fileChooser.getSelectedFile().getName());
	    	}
		}
		else if(e.getSource().equals(exit))
			System.exit(0);
		else if(e.getSource().equals(instruction))
		{
			UIManager.put("OptionPane.messageFont", PLAIN_FONT);
			JOptionPane.showMessageDialog(this, instructionMessage, "Instruction", JOptionPane.PLAIN_MESSAGE);
			
		}
		else if(e.getSource().equals(deidentifyButton))
		{
			if(!noOfRecordsField.getText().equals(""))
			{
				try{
					int noOfRecords = Integer.parseInt(noOfRecordsField.getText());
					if(noOfRecords > deidentifier.getNoOfRecords())
					{
						info.setText("<html><font color = 'red'>No. of records to be disclosed must be a number from (1-."+ deidentifier.getNoOfRecords() +")</font>");
						info.setBounds(10, 15, 700, 15);
						return;
					}
				}
				catch (Exception a){
					info.setText("<html><font color = 'red'>No. of records to be disclosed is not a valid number. </font>");
					info.setBounds(10, 15, 700, 15);
					return;
				}
			}
			if(duplicateFieldNumber(randomReplaceField.getText()+ "," + swapField.getText() + "," + pseudonymField.getText()))
			{
				info.setText("<html><font color = 'red'>Choose only one de-identification method per field. </font></html>");
				info.setBounds(10, 15, 700, 15);
				return;
			}
			else
			{
				if(!noOfRecordsField.getText().equals(""))
					deidentifier.subsample(Integer.parseInt(noOfRecordsField.getText()));
				try{
					if(!randomReplaceField.getText().equals(""))
					{
						String[] randomReplaceFields = randomReplaceField.getText().split("\\s*,\\s*");
						for(int i = 0; i < randomReplaceFields.length; i++)
							deidentifier.replaceRandomly(Integer.parseInt(randomReplaceFields[i])-1);
					}
					if(!swapField.getText().equals(""))
					{
						String[] swapFields = swapField.getText().split("\\s*,\\s*");
						for(int i = 0; i < swapFields.length; i++)
							deidentifier.swap(Integer.parseInt(swapFields[i])-1);
					}
					if(!pseudonymField.getText().equals(""))
					{
						String[] pseudonymFields = pseudonymField.getText().split("\\s*,\\s*");
						for(int i = 0; i < pseudonymFields.length; i++)
							deidentifier.pseudonimize(Integer.parseInt(pseudonymFields[i])-1);
					}
							
					fileChooser.setSelectedFile(new File("de-identified data set.csv"));
					int rVal = fileChooser.showSaveDialog(this);
		            if (rVal == JFileChooser.APPROVE_OPTION) {
		                 deidentifier.writeCSV(fileChooser.getCurrentDirectory().toString()+ "\\" + fileChooser.getSelectedFile().getName());
		                 info.setText("<html><font color='green'>File saved.</font></html>");
						 info.setBounds(10, 15, 700, 15);
		            }    
				}
				catch (Exception exception)
				{
					info.setText("<html><font color='red'>Invalid field number</font></html>");
					info.setBounds(10, 15, 700, 15);
				}
			}
			
		}
	}
	
	public boolean duplicateFieldNumber(String input)
	{
		String[] inputArray = input.split("\\s*,\\s*");

		for (int i = 0; i < inputArray.length - 1; i++) 
		{
			for (int j = i + 1; j < inputArray.length; j++) 
			{	
				if(inputArray[i].equals(inputArray[j]) && inputArray[i].length()>0)
				{
					if(!inputArray[i].equals(" "));
						return true;
				}
			}    
		}
		return false;
	}
	
	public static void main(String[] args) 
	{	
		try {
			javax.swing.UIManager.setLookAndFeel( javax.swing.UIManager.getSystemLookAndFeelClassName());
		} catch (UnsupportedLookAndFeelException | ClassNotFoundException | InstantiationException | IllegalAccessException e1) {
		} 
		new DeidentificationTool();
	}

}
